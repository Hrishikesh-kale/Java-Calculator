package javaapplication2;

import javax.swing.JOptionPane;

public class JavaApplication2 {

    public static void main(String[] args) {
        JOptionPane.showMessageDialog(null, "You have succesfully loggin in", "Dialouge Box", JOptionPane.INFORMATION_MESSAGE);
    }

}
